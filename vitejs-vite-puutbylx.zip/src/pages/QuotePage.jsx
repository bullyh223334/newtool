import React from "react";

export default function QuotePage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Quote Page</h2>
      <p>This is where quotes will be managed.</p>
    </div>
  );
}
