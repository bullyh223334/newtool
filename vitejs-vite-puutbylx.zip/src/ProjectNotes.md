



Things to add: 

Quote pages
 - Select product from drop down 
 - Break quote in to Hardware and SW
 - Add modal for software selection




Dashboard



System -
 - Add test quotes and products